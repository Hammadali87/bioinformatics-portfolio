DE Advisor 1.2 — Statistical Design Edition
===========================================

DE Advisor is a local R Shiny application for differential expression analysis.
Version 1.2 builds on the 1.1 data-integrity and GEO-aware workflow, adding
covariate-aware design matrices, an optional limma treat test, configurable
expression filtering, and clearer numerical reporting.

RUNNING THE APPLICATION
1. Extract this ZIP to a normal folder.
2. If this is the first run on this computer, double-click 1_Install_Once.bat.
3. Double-click 2_Start_DE_Advisor.bat.
4. Keep the command window open while using the application.

R 4.6 is the target environment. Package availability can depend on the matching
R/Bioconductor release. If installation reports an error, save the complete
message before retrying.

VERSION 1.2 CHANGES
- Optional covariate adjustment from a sample sheet. Choose measured variables
  such as age, sex, post-mortem interval (PMI), RNA integrity number (RIN), or
  batch only when they are available and scientifically justified.
- Covariates are aligned to expression samples by sample ID. Missing values,
  invalid values, redundant/confounded design matrices, and insufficient
  residual degrees of freedom are blocked with explanatory messages.
- Numeric covariates with more than five distinct values are treated as
  continuous; text and low-cardinality variables are treated as categorical.
  Review this automatic type handling before running the model.
- limma now offers two inference modes: eBayes with a post-hoc fold-change
  threshold (for 1.1 compatibility), or treat, which tests against the selected
  minimum absolute log2 fold-change threshold. The 1.2 default is treat.
- The normalized-data expression filter is configurable on the log2(value + 1)
  scale, with a configurable minimum number of samples. The default threshold
  of 1 retains the 1.1 rule.
- Results display p-values in scientific notation. CSV export preserves full
  available R numeric precision. Values below machine representable range can
  still underflow to zero; they are flagged in the on-screen table.
- PCA scaling help text explains the effect of gene-wise unit-variance scaling.
- Methods text now records the selected statistical test, filtering threshold,
  covariates, duplicate handling, and PCA scaling setting.

COVARIATE WORKFLOW
To adjust for covariates, choose "From a sample sheet" when defining groups.
The sheet must contain one row per expression sample and columns for sample ID,
group, and any covariates. Select covariates in the new control. The app does not
automatically decide which covariates belong in a model. Do not include variables
solely because they are available: consider the study design, confounding,
missingness, collinearity, and the number of biological replicates. Covariate
adjustment cannot correct an inappropriate experimental design.

For GSE68719, age, sex, PMI, RIN and batch should be considered only after
checking the actual sample metadata and published study design. The GSE68719
curated workflow guidance remains advisory; the uploaded file's data type must
still be confirmed by the user. The current GEO lookup does not automatically
retrieve or merge phenotype metadata into a sample sheet.

STATISTICAL NOTES
- DESeq2 is for explicitly confirmed raw integer counts. It uses the selected
  covariates and group in its design when a sample sheet is supplied.
- limma is for normalized or log-scale expression, not raw counts in this
  release. Normalized non-negative values are transformed with log2(value + 1).
- limma treat tests the null that the absolute log2 fold change does not exceed
  the selected threshold. This differs from eBayes followed by a post-hoc
  observed-fold-change cutoff.
- The normalized-data filter is applied across all samples before testing.
  The default log2(value + 1) threshold is 1 in at least 3 samples.
- Duplicate gene identifiers still require an explicit policy. Summing is only
  defensible for non-overlapping raw-count features belonging to the same gene.
  Highest-mean retention is a legacy compatibility option, not a universal
  biological summarization method.
- PCA gene-wise scaling is a visualization choice, not part of the differential
  expression model.

LOCAL DATA AND NETWORK USE
Expression files are processed locally by the Shiny application. GEO metadata
lookup and optional KEGG enrichment require an internet connection.

TEST STATUS
The source has undergone static review and packaging checks. R is not available
in the development environment, so this ZIP has NOT been runtime-tested in R.
Open it in the user's R 4.6 environment and complete the smoke tests below before
calling it a verified release.

RECOMMENDED SMOKE TESTS
1. Re-run GSE68719 using the same 73 samples and two groups (PD 29, Control 44)
   with the same duplicate policy and default filter; note that treat is now the
   default statistical test, so results will not be numerically identical to 1.1.
2. Run limma eBayes mode and confirm it reproduces the 1.1-compatible method.
3. Import a sample sheet with numeric age and categorical sex/batch; select them
   and confirm the methods text reports the covariates.
4. Test missing covariate values and a confounded covariate; both should be blocked.
5. Compare on-screen p-value notation with the downloaded CSV.
6. Test raw-count DESeq2 with and without covariates on a suitable count dataset.
7. Test PCA with scaling enabled and disabled.

@echo off
setlocal
set "RS="
for /f "delims=" %%i in ('dir /b /ad /o-n "C:\Program Files\R\R-*" 2^>nul') do if not defined RS set "RS=C:\Program Files\R\%%i\bin\Rscript.exe"
if not defined RS (
  echo R was not found. Please install R first from:
  echo https://cran.r-project.org/bin/windows/base/
  pause
  exit /b 1
)
set "APP=%~dp0"
set "APP=%APP:\=/%"
echo Starting DE Advisor. Keep this window open while you use the app. Close it to stop.
"%RS%" -e "shiny::runApp('%APP%', launch.browser = TRUE)"
pause

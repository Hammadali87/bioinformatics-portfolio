options(repos = c(CRAN = "https://cloud.r-project.org"))

# Core user-interface and visualization packages.
install.packages(c("shiny", "ggplot2", "pheatmap", "RColorBrewer", "BiocManager"))

# Core statistical engines. Enrichment packages are installed separately because
# they are optional and can be large.
BiocManager::install(c("limma", "DESeq2", "SummarizedExperiment"),
                     update = FALSE, ask = FALSE)

cat("\nCore installation finished. Optional enrichment packages can be installed\n",
    "by running install_optional_packages.R.\n",
    "You can now start DE Advisor with 2_Start_DE_Advisor.bat.\n", sep = "")

options(repos = c(CRAN = "https://cloud.r-project.org"))
if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
BiocManager::install(c("clusterProfiler", "org.Hs.eg.db", "enrichplot"),
                     update = FALSE, ask = FALSE)
cat("Optional human GO/KEGG enrichment packages installed.\n")

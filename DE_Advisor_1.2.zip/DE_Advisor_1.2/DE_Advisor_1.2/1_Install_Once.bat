@echo off
setlocal
set "RS="
for /f "delims=" %%i in ('dir /b /ad /o-n "C:\Program Files\R\R-*" 2^>nul') do if not defined RS set "RS=C:\Program Files\R\%%i\bin\Rscript.exe"
if not defined RS (
  echo R was not found. Please install R first from:
  echo https://cran.r-project.org/bin/windows/base/
  start https://cran.r-project.org/bin/windows/base/
  pause
  exit /b 1
)
echo Using %RS%
echo Installing packages. This can take 10-30 minutes the first time. Do not close this window.
"%RS%" "%~dp0install_packages.R"
pause
